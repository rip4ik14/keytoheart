// Путь: app/admin/metadata.ts
export const metadata = {
    title: "АДМИН-панель KEY TO HEART",
  };
  